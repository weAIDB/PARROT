# LLMTranslator-DeepSeek-V2 by ExampleTeam

This document provides instructions for setting up the environment and running the SQL translation model for the PARROT Challenge.

## 1. Environment Setup & Execution

Our submission is designed for maximum convenience. The `run_translation.sh` script handles everything from environment setup to execution in a single command.

### Step 1: Configure API Credentials
This translator uses a large language model API (e.g., DeepSeek) for translation. You must configure the API endpoint and your API key as environment variables before running the script.

```bash
export LLM_API_URL="YOUR_API_ENDPOINT_URL"
export LLM_API_KEY="YOUR_API_KEY"
```

**Note:** As requested by the PARROT Submission Guidelines, please provide the API key in the submission email. We will set these environment variables before running the code.

### Step 2: Run the Translation
The entire process is started by the single `run_translation.sh` script. It will automatically create a Python virtual environment inside the project folder, install the necessary dependencies from `requirements.txt`, and then run the translation.

The script takes the input JSON file path and the desired output JSON file path as arguments.

**Single Execution Command:**
```bash
bash code/run_translation.sh /path/to/input.json /path/to/output.json
```

**Example:**
```bash
bash code/run_translation.sh sample_input.json sample_output.json
```

---

## 2. Model
This solution is based on an API call to a large language model (e.g., DeepSeek-V2) and does not require downloading any model weights.

## 3. Resource and Time Requirements

-   **Inference Resources:**
    -   **CPU:** 2 cores
    -   **Memory:** 4 GB
    -   **GPU:** Not required.
    -   **Network:** An active internet connection is required during the initial setup to download Python packages. After setup, it's needed to access the LLM API.

-   **Approximate Runtime:**
    -   The runtime depends on the API's response speed and the number of queries in the input file.
    -   Based on our tests with the development set, the approximate runtime is **30 minutes**. The first run might be slightly longer due to dependency installation. 