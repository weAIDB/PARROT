import re
import json
import traceback
import os
import argparse
import logging
from typing import Dict, Any

import requests
from tqdm import tqdm

from translate_prompt import SYSTEM_PROMPT_NA, USER_PROMPT_NA


def setup_logging(output_file):
    log_file = os.path.splitext(output_file)[0] + ".log"
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        handlers=[
            logging.FileHandler(log_file),
            logging.StreamHandler()
        ]
    )


def parse_llm_answer(answer_raw: Dict[str, Any]) -> Dict[str, Any]:
    """
    Parses the raw response from the LLM to extract the translated SQL, reasoning, and confidence.
    """
    if not answer_raw or "choices" not in answer_raw or not answer_raw["choices"]:
        return {"Answer": "Invalid LLM response format.", "Reasoning": "Empty or invalid response.", "Confidence": 0}

    content = answer_raw["choices"][0]["message"]["content"]

    try:
        # First, try to find a JSON block and parse it
        json_match = re.search(r'```json\s*(\{.*?\})\s*```', content, re.DOTALL)
        if json_match:
            json_str = json_match.group(1)
            # The model sometimes messes up quoting, let's try to fix it.
            json_str = json_str.replace('\\"', '"').replace('\\\'', '\'')
            data = json.loads(json_str)
            if "Answer" in data and "Reasoning" in data and "Confidence" in data:
                try:
                    data["Confidence"] = float(data["Confidence"])
                except (ValueError, TypeError):
                    data["Confidence"] = 0.8  # Default value
                return data

        # If no JSON block, try to parse the whole content as JSON
        try:
            data = json.loads(content)
            if "Answer" in data and "Reasoning" in data and "Confidence" in data:
                return data
        except json.JSONDecodeError:
            pass  # Fallback to regex

        # Fallback to regex matching if JSON parsing fails
        pattern = r'"Answer":\s*"(.*?)",\s*"Reasoning":\s*"(.*?)",\s*"Confidence":\s*([0-9.]+)'
        match = re.search(pattern, content, re.DOTALL)
        if match:
            return {
                "Answer": match.group(1).replace('\\\"', '\"'),
                "Reasoning": match.group(2).replace('\\\"', '\"'),
                "Confidence": float(match.group(3))
            }
        
        logging.warning("Failed to parse LLM answer using all methods.")
        return {"Answer": "Answer not returned in the given format!", "Reasoning": content, "Confidence": 0}

    except Exception as e:
        logging.error(f"Error parsing LLM answer: {e}\nContent: {content}")
        traceback.print_exc()
        return {"Answer": str(e), "Reasoning": "Error occurred during parsing!", "Confidence": 0}


def load_input_data(input_path: str):
    with open(input_path, "r", encoding="utf-8") as f:
        return json.load(f)


def construct_message(src_dialect: str, tgt_dialect: str, sql: str):
    messages = [
        {
            "role": "system", "content": SYSTEM_PROMPT_NA.format(src_dialect=src_dialect,
                                                                 tgt_dialect=tgt_dialect)
        },
        {
            "role": "user", "content": USER_PROMPT_NA.format(src_dialect=src_dialect,
                                                             tgt_dialect=tgt_dialect,
                                                             sql=sql)
        }
    ]
    return messages


def get_llm_result(model: str, messages: list):
    url = os.getenv("LLM_API_URL")
    bearer_token = os.getenv("LLM_API_KEY")

    if not url or not bearer_token:
        raise ValueError("Environment variables LLM_API_URL and LLM_API_KEY must be set.")

    headers = {
        "Authorization": f"Bearer {bearer_token}",
        "Content-Type": "application/json"
    }

    payload = {
        "model": model,
        "messages": messages,
        "temperature": 0.0,
        "max_tokens": 2048,
    }

    try:
        response = requests.post(url, headers=headers, json=payload, timeout=120)
        response.raise_for_status()  # Raise an exception for bad status codes
        return response.json()
    except requests.exceptions.RequestException as e:
        logging.error(f"Request to LLM API failed: {e}")
        return None


def run_translation(input_path: str, output_path: str):
    # 1. Load the SQL data
    sql_data = load_input_data(input_path)

    model = "deepseek-v2"

    total_result = []
    processed_ids = set()

    # Resume logic: Check if output file exists and load previous results
    if os.path.exists(output_path):
        try:
            with open(output_path, "r", encoding="utf-8") as f:
                total_result = json.load(f)
                processed_ids = {item['id'] for item in total_result if 'id' in item}
            logging.info(f"Resuming translation. Loaded {len(total_result)} previous results from {output_path}")
        except (json.JSONDecodeError, IOError) as e:
            logging.warning(f"Could not load existing output file {output_path}. Starting from scratch. Error: {e}")
            total_result = []

    # 2. Iterate through each SQL item
    for item in tqdm(sql_data, desc="Translating SQL"):
        if item.get('id') in processed_ids:
            logging.info(f"Skipping already processed item with id: {item.get('id')}")
            continue

        # 3. Construct the prompt to LLM
        src_dialect = item["source_dialect"]
        tgt_dialect = item["target_dialect"]
        sql = item["source_sql"]
        messages = construct_message(src_dialect, tgt_dialect, sql)

        # 4. Get the result from LLM
        llm_response_raw = get_llm_result(model, messages)

        if llm_response_raw is None:
            logging.error(f"Skipping item {item.get('id')} due to API error.")
            continue
            
        # 5. Parse the result from LLM
        result_json = parse_llm_answer(llm_response_raw)
        
        # 6. Format output
        output_item = item.copy()
        output_item["translated_sql"] = result_json.get("Answer", "Translation failed.")
        # Optional: include more details for debugging if needed
        # output_item["llm_reasoning"] = result_json.get("Reasoning")
        # output_item["llm_confidence"] = result_json.get("Confidence")
        # output_item["llm_raw_response"] = llm_response_raw
        
        total_result.append(output_item)
        processed_ids.add(item.get('id'))

        # 7. Dump the result immediately to support resuming
        try:
            with open(output_path, "w", encoding="utf-8") as wf:
                json.dump(total_result, wf, indent=2, ensure_ascii=False)
        except IOError as e:
            logging.critical(f"Fatal: Could not write to output file {output_path}. Error: {e}")
            # If we can't write, there's no point in continuing.
            break

def main():
    parser = argparse.ArgumentParser(description="Translate SQL queries using an LLM API.")
    parser.add_argument("--input", required=True, help="Path to the input JSON file.")
    parser.add_argument("--output", required=True, help="Path to the output JSON file.")
    args = parser.parse_args()

    setup_logging(args.output)
    
    logging.info(f"Starting translation process for {args.input}")
    try:
        run_translation(args.input, args.output)
        logging.info(f"Translation process finished. Results saved to {args.output}")
    except Exception as e:
        logging.critical(f"An unhandled exception occurred: {e}")
        traceback.print_exc()

if __name__ == "__main__":
    main() 