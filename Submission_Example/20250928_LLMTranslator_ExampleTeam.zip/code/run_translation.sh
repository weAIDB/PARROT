#!/bin/bash

# Set strict error handling
set -e
set -o pipefail

# --- Usage ---
# bash code/run_translation.sh /path/to/input.json /path/to/output.json
# ---------------

# Check if input and output file paths are provided
if [ "$#" -ne 2 ]; then
    echo "Usage: $0 <input_file> <output_file>"
    exit 1
fi

INPUT_FILE=$1
OUTPUT_FILE=$2

# The script is assumed to be in the same directory as this shell script.
# This ensures that the script can be run from any directory.
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
# The project root is one level up from the 'code' directory
PROJECT_ROOT_DIR="$(dirname "$SCRIPT_DIR")"

# --- Environment Setup ---
VENV_DIR="$PROJECT_ROOT_DIR/venv"
echo "Checking for virtual environment in $VENV_DIR..."

# Use python3, which is a common alias for Python 3.
# The user can change this if their python executable has a different name.
PYTHON_EXEC=python3
if ! command -v $PYTHON_EXEC &> /dev/null
then
    PYTHON_EXEC=python
    if ! command -v $PYTHON_EXEC &> /dev/null
    then
        echo "Error: Python is not installed or not in PATH."
        exit 1
    fi
fi


if [ ! -d "$VENV_DIR" ]; then
    echo "Virtual environment not found. Creating one..."
    $PYTHON_EXEC -m venv "$VENV_DIR"
    echo "Virtual environment created."
fi

echo "Activating virtual environment..."
source "$VENV_DIR/bin/activate"

# Use a marker file to check if dependencies are already installed
# to avoid running pip install every time.
MARKER_FILE="$VENV_DIR/.dependencies_installed"
if [ ! -f "$MARKER_FILE" ]; then
    echo "Installing dependencies from requirements.txt..."
    pip install -r "$PROJECT_ROOT_DIR/requirements.txt"
    touch "$MARKER_FILE"
    echo "Dependencies installed."
else
    echo "Dependencies are already installed."
fi
# --- End of Environment Setup ---

echo "Starting SQL translation..."
echo "Input file: $INPUT_FILE"
echo "Output file: $OUTPUT_FILE"

# Run the Python translation script
python "$SCRIPT_DIR/llm_translator.py" --input "$INPUT_FILE" --output "$OUTPUT_FILE"

echo "Translation completed successfully." 